#ifndef _TOTAL_H
#define _TOTAL_H

//#define WINVER 0x0501  //Windows XP 
//#define WINVER 0x0500  //Windows 2000
//#define WINVER 0x0500  //Windows

	#include  "CH341PAR.h"
	#include  "CH341PARDlg.h"
	#include  "CtrlSheet.h"
	#include  "EppPage.h"
	#include  "MemPage.h"
	#include  "OtherPage.h"
	#include  "CH341DLL.h"
    #include  "I2CSPage.h"
    #include "EeprPage.h"
    #include "LEDBTDisp.h"
#endif